#import <Foundation/Foundation.h>

//! Project version number for ThreeDS_iOS_SDK.
FOUNDATION_EXPORT double ThreeDS_iOS_SDKVersionNumber;

//! Project version string for ThreeDS_iOS_SDK.
FOUNDATION_EXPORT const unsigned char ThreeDS_iOS_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ThreeDS_iOS_SDK/PublicHeader.h>


